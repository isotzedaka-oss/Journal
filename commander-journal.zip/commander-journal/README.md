# יומן מפקד — מדריך התקנה מלא

אפליקציה שלמה: לוח שנה, עמוד יום עם לוז/משימות/דגשים/חריגים/הערות/מדבקות, שמירה אוטומטית אמיתית ל-Supabase (בסיס נתונים אמיתי בענן).

זמן משוער: 15-20 דקות, כולל הרשמה לשני שירותים חינמיים.

---

## שלב 1 — יצירת פרויקט Supabase (5 דקות)

1. גלוש ל-https://supabase.com ולחץ **Start your project**.
2. הירשם עם Google או Email (חינמי, לא צריך כרטיס אשראי).
3. לחץ **New project**. תן שם (למשל `commander-journal`), בחר סיסמה לבסיס הנתונים (שמור אותה בצד, לא תצטרך אותה בפועל בשלבים הבאים) ובחר region קרוב (למשל Europe).
4. חכה כדקה עד שהפרויקט מוכן.

## שלב 2 — יצירת הטבלה

1. בתפריט הצד לחץ על **SQL Editor**.
2. לחץ **New query**, הדבק את הקוד הבא, ולחץ **Run**:

```sql
create table journal_entries (
  date date primary key,
  summary text default '',
  mood text,
  schedule jsonb default '[]'::jsonb,
  tasks_today jsonb default '[]'::jsonb,
  tasks_tomorrow jsonb default '[]'::jsonb,
  maintain jsonb default '[]'::jsonb,
  improve jsonb default '[]'::jsonb,
  exceptions jsonb default '[]'::jsonb,
  notes text default '',
  stickers jsonb default '[]'::jsonb,
  updated_at timestamptz default now()
);

alter table journal_entries enable row level security;

create policy "allow all access"
  on journal_entries
  for all
  using (true)
  with check (true);
```

**הערה על אבטחה:** המדיניות הזו (`using (true)`) פותחת גישה לכל מי שיש לו את כתובת האתר והמפתח הציבורי. זה מספיק ליומן אישי שאתה היחיד שמכיר את הקישור אליו. אם בעתיד תרצה הגנה אמיתית (סיסמה/כניסה), תגיד לי ונוסיף Supabase Auth.

## שלב 3 — איסוף המפתחות

1. בתפריט הצד: **Project Settings** (גלגל שיניים) → **API**.
2. תעתיק שני ערכים:
   - **Project URL** (נראה כך: `https://xxxxx.supabase.co`)
   - **anon public** key (מחרוזת ארוכה תחת "Project API keys")

שמור את שניהם - תצטרך אותם בשלב הבא ובדיפלוי.

## שלב 4 — הרצה מקומית (אופציונלי, לבדיקה)

דורש שיהיה מותקן Node.js במחשב. אם אין לך, אפשר לדלג ישר לשלב 5 (Deploy) - זה לא חובה כדי שהאתר יעבוד.

```bash
cd commander-journal
npm install
cp .env.example .env.local
```

פתח את `.env.local` ומלא את שני הערכים שהעתקת:

```
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbG....
```

ואז:

```bash
npm run dev
```

יפתח כתובת מקומית (`http://localhost:5173`) שתוכל לבדוק בדפדפן.

## שלב 5 — פרסום אמיתי עם Vercel (10 דקות)

1. העלה את התיקייה הזו ל-GitHub (אם אין לך חשבון, הרשמה חינמית ב-https://github.com):
   - צור repository חדש (למשל `commander-journal`).
   - העלה את כל הקבצים (או דרך GitHub Desktop / דרך `git push` אם אתה מכיר).
2. גלוש ל-https://vercel.com והירשם (הכי קל: "Continue with GitHub").
3. לחץ **Add New → Project**, בחר את ה-repository שיצרת.
4. לפני שלוחצים Deploy, פתח **Environment Variables** והוסף:
   - `VITE_SUPABASE_URL` = הכתובת מ-Supabase
   - `VITE_SUPABASE_ANON_KEY` = המפתח מ-Supabase
5. לחץ **Deploy**. אחרי דקה תקבל כתובת אמיתית (למשל `commander-journal.vercel.app`) שעובדת מכל מכשיר, לתמיד.
6. באייפון: פתח את הכתובת ב-Safari, לחץ על כפתור השיתוף, ובחר **הוסף למסך הבית** - עכשיו יש לך אייקון אמיתי שפותח ישר את היומן.

---

## איך זה עובד

- כל יום הוא שורה אחת בטבלה `journal_entries`, עם התאריך כמפתח.
- לוחצים על יום בלוח השנה → האפליקציה שולפת את השורה (אם יש) או פותחת יום ריק.
- כל שינוי (הקלדה, סימון משימה) נשמר אוטומטית כ-0.7 שניות אחרי שהפסקת להקליד - בלי כפתור שמירה.
- לוח השנה מציג נקודת צבע לפי מצב היום, ומספר משימות שהושלמו מתוך הסך הכל.

## אם משהו לא עובד

- **מסך לבן / שגיאה בקונסול** → כמעט תמיד `VITE_SUPABASE_URL`/`VITE_SUPABASE_ANON_KEY` חסרים או שגויים ב-Vercel (Environment Variables) - תבדוק שם קודם.
- **"שגיאה: ..." מופיע ליד סטטוס השמירה** → תעתיק לי את הטקסט המדויק ואני אדע להגיד מה קרה (זה עכשיו שגיאת Supabase אמיתית עם הודעה ברורה, לא כמו הבעיות הקודמות).
